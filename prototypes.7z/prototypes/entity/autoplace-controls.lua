data:extend(
{
  {
    type = "autoplace-control",
    name = "arachnid-base",
    richness = false,
    order = "c-z",
    category = "enemy"
  }
}
)
